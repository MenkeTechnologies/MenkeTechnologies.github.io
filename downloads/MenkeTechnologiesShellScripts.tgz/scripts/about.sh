#!/usr/bin/env bash
#{{{                    MARK:Header
#**************************************************************
##### Author: MenkeTechnologies
##### GitHub: https://github.com/MenkeTechnologies
##### Date: Mon Jul 10 12:01:32 EDT 2017
##### Purpose: bash script to document
##### Notes:
#}}}***********************************************************
function zpwrAllRemotes() {

    while read; do
        printf "\x1b[1;34m$REPLY"
        printf "\x1b[0m\x0a"
        git remote show "$REPLY"
    done < <(git remote)
}

function banner() {

    local version info fetch push lastcommit

    if [[ -d "$ZPWR" ]]; then
        if cd "$ZPWR"; then
            version="$(git describe --tags $(git rev-list --tags --max-count=1) | perl -pe 's@[\t ]@@')"
            info="$(git tag -l -n9 "$version" | perl -pe 's@[\t ]+@ @')"
            fetch="$(git remote -v | grep zpwr | grep fetch | head -n 1 | perl -pe 's@[\t ]+@    @')"
            push="$(git remote -v | grep zpwr | grep push | tail -n 1 | perl -pe 's@[\t ]+@    @')"
            lastcommit="$(git log --oneline -n 1)"
        fi
    fi

    # Cyberpunk color codes
    local cyan="\x1b[1;36m"
    local magenta="\x1b[1;35m"
    local yellow="\x1b[1;33m"
    local green="\x1b[1;32m"
    local red="\x1b[1;31m"
    local dim="\x1b[2m"
    local reset="\x1b[0m"
    local blink="\x1b[5m"
    local bg_black="\x1b[40m"
    local bold="\x1b[1m"

    printf "${bg_black}"
    echo
    printf "${dim}${cyan}"
    cat <<\EOF
    ┌──────────────────────────────────────────────────────────┐
    │  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
EOF
    printf "${reset}${bg_black}${magenta}"
    cat <<\EOF
    │    ███████╗██████╗ ██╗    ██╗██████╗     //SYSTEMS//    │
    │    ╚══███╔╝██╔══██╗██║    ██║██╔══██╗                   │
    │      ███╔╝ ██████╔╝██║ █╗ ██║██████╔╝                   │
    │     ███╔╝  ██╔═══╝ ██║███╗██║██╔══██╗                   │
    │    ███████╗██║      ╚███╔███╔╝██║  ██║                   │
    │    ╚══════╝╚═╝       ╚══╝╚══╝ ╚═╝  ╚═╝                   │
EOF
    printf "${reset}${bg_black}${dim}${cyan}"
    cat <<\EOF
    │  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
    └──────────────────────────────────────────────────────────┘
EOF

    printf "${reset}${bg_black}"
    echo
    printf "${cyan}${bold}"
    cat <<\EOF
      ╔══════════════════════════════════════════════════════╗
      ║  ▓▓ M E N K E   T E C H N O L O G I E S   ▓▓      ║
      ╚══════════════════════════════════════════════════════╝
EOF

    printf "${reset}${bg_black}"
    echo
    printf "${dim}${green}      > INITIALIZING NEURAL LINK...${reset}${bg_black}\n"
    printf "${dim}${green}      > ZPWR KERNEL ONLINE${reset}${bg_black}\n"
    echo

    printf "${yellow}${bold}"
    cat <<EOF
      ┌─── VERSION ──────────────────────────────────────────┐
      │  $info
      └──────────────────────────────────────────────────────┘
EOF

    printf "${reset}${bg_black}"
    echo
    printf "${cyan}      ┌─── NETWORK ─────────────────────────────────────────┐\n"
    printf "      │  ${dim}${cyan}FETCH >>${reset}${bg_black}${cyan} %s\n" "$fetch"
    printf "      │  ${dim}${cyan}PUSH  >>${reset}${bg_black}${cyan} %s\n" "$push"
    printf "${cyan}      └──────────────────────────────────────────────────────┘\n"

    printf "${reset}${bg_black}"
    echo
    printf "${magenta}"
    cat <<EOF
      ┌─── LAST TRANSMISSION ───────────────────────────────┐
      │  $lastcommit
      └──────────────────────────────────────────────────────┘
EOF

    printf "${reset}${bg_black}"
    echo
    printf "${dim}${red}"
    cat <<\EOF
      ██████████████████████████████████████████████████████
      ░░░░░░░░░░░ WELCOME TO THE GRID ░░░░░░░░░░░░░░░░░░░░
      ██████████████████████████████████████████████████████
EOF
    echo
    printf "${reset}"

    #if [[ -d "$ZPWR" ]]; then
    #if cd "$ZPWR";then
    #{
    #zpwrAllRemotes
    #} | perl -pe 's@(.*)@\x1b[31m$1@'

    #fi
    #fi

    printf "\x1b[0m"
}

banner
